package com.octoforce.games.ld29.model;

import java.util.Iterator;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.octoforce.games.ld29.WorldRenderer;

public class World {
	
	public int width;
	public int height;
	
	Array<Block> blocks;
	Array<MovingBlock> movingBlocks;
	Array<Star> stars;
	Player player;
	boolean [] dirt;
	boolean [][] kill;
	Level level;
	float stateTime;
	int starsCollected;
	int starsTotal;
	public boolean firstStar = false;
	static String [] levels = { "data/levels/level1.csv", "data/levels/level2.csv" };
	int currentLevel;
	Vector2 flag;
	boolean finished = false;
	
	public World() {
		this.blocks = new Array<Block>();
		
		this.width = (int) WorldRenderer.CAMERA_WIDTH;
		this.height = (int) WorldRenderer.CAMERA_HEIGHT;

		this.dirt = new boolean [width * height];
		this.kill = new boolean [width][height];
		
		this.stateTime = 0;
		stars = new Array<Star>();
		starsCollected = 0;
		
		currentLevel = 0;
		this.player = new Player(0, 0);
		
		reset();
	}
	
	public boolean hasNextLevel() {
		return currentLevel < 1;
	}
	
	public void nextLevel() {
		stars = new Array<Star>();
		currentLevel++;
		reset();
	}
	
	public void reset() {
		
		level = new Level(Gdx.files.internal(levels[currentLevel]));
		this.movingBlocks = new Array<MovingBlock>();
		
		char [][] data = getLevelData();
		resetBlocks();
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				if (data[i][j] == 'x')
					dirt[j + (height - i - 1) * width] = true;
				if (data[i][j] == 'v')
					kill[j][height - i - 1] = true;
				if (data[i][j] == 's')
					stars.add(new Star(j, height - i - 1));
				if (data[i][j] == 'e')
					flag = new Vector2(j, height - i - 1);
			}
		}
		switch (currentLevel) {
		case 0:
			initLevel1();
			break;
		case 1:
			initLevel2();
			break;
		}
	}
	
	private void initLevel1() {
		player.setPosition(new Vector2(3, 14));
		player.upwards = true;
		movingBlocks.add(new MovingBlock(18, 5, 4, 1, new Vector2(18 , 5), new Vector2(26, 5), 5f));
	}
	
	private void initLevel2() {
		player.setPosition(new Vector2(0, 12));
		player.upwards = true;
		movingBlocks.add(new MovingBlock(3, 7, 4, 1, new Vector2(3, 7), new Vector2(10, 7), 4f));
		movingBlocks.add(new MovingBlock(20, 25, 4, 1, new Vector2(20, 25), new Vector2(25, 25), 5f));
		movingBlocks.add(new MovingBlock(17, 10, 4, 1, new Vector2(17, 10), new Vector2(21, 10), 3f));
		movingBlocks.add(new MovingBlock(30, 24, 4, 1, new Vector2(30, 24), new Vector2(37, 24), 6f));
		movingBlocks.add(new MovingBlock(26, 11, 4, 1, new Vector2(26, 11), new Vector2(34, 11), 3f));
	}
	
	public void update(float delta) {
		stateTime += delta;
		for (MovingBlock b : movingBlocks)
			b.update(delta);
		Star temp;
		for (Iterator<Star> it = stars.iterator(); it.hasNext();) {
			temp = it.next();
			if (temp.bounds.overlaps(player.bounds)) {
				if (starsCollected == 0) {
					firstStar = true;
				}
				starsCollected ++;
				it.remove();
			}
		}
	}
	
	public Vector2 findOpposite(Rectangle rect, boolean upwards) {
		Vector2 v = new Vector2(rect.x, 0);
		
		int startX = (int) Math.floor(rect.x);
		int endX = (int) Math.ceil(rect.x + rect.width);
		
		int endY = (int) rect.y + (upwards ? (int) rect.height : -1);
		
		for (MovingBlock b : getMovingBlocks()) {
			if (b.player != null && b.bounds.overlaps(player.bounds)) {
				if (!upwards)
					endY -= b.bounds.height - 1;
				else
					endY += b.bounds.height - 1;
			}
		}
		
		for (int i = startX; i < endX; i++) {
			// keep going down/up until there is an empty space == !dirt
			boolean dirtCheck = dirt[i + width * endY];
			while (dirt[i + width * endY])
				endY += upwards ? 1 : -1;
		}
		
		v.y = upwards ? endY : endY + 1;
		
		for (MovingBlock b : getMovingBlocks()) {
			if (b.player != null) {
				
			}
			if (b.containsIncludingBorder(v.x, v.y)) {
				System.out.println("Attached");
				v.y += (upwards ? 1 : -1) * b.getBounds().height;
				b.setPlayer(player);
			}
		}
		
		return v;
	}
	
	public float distanceToFirstBlockHorizontal(Rectangle bounds, boolean left, boolean upwards) {
		int y = 0;
		if (upwards)
			y = (int) bounds.y;
		else
			y = (int) (bounds.y + bounds.height) - 1;
		float distance = 0;
		if (left) {
			int x = (int) Math.floor(bounds.x);
			try {
				while (!dirt[y * width + x])
					x--;
			} catch (ArrayIndexOutOfBoundsException e) {
				return Integer.MAX_VALUE;
			}
			distance = bounds.x - x - 1;
		}
		else {
			int x = (int) Math.ceil(bounds.x + bounds.width);
			try {
				while (!dirt[y * width + x])
					x++;
			} catch (ArrayIndexOutOfBoundsException e) {
				return Integer.MAX_VALUE;
			}
			distance = x - (bounds.x + bounds.width);
		}
		return distance;
	}
	
	public float distanceToFirstBlockVertical(Rectangle bounds, boolean upwards) {
		int startX = (int) Math.floor(bounds.x);
		int endX = (int) Math.ceil(bounds.x + bounds.width);

		for (MovingBlock b : getMovingBlocks())
			if (b.player != null && b.bounds.overlaps(player.bounds)) {
				return 0;
			}
		
		float distance = 0;

		try {
			if (upwards) {
				int y = (int) Math.ceil(bounds.y);
				boolean found = false;
				while (!found) {
					y--;
					for (int i = startX; i < endX; i++) {
						if (dirt[y * width + i]) {
							found = true;
							break;
						}
					}
				}
				distance = bounds.y - y - 1;
				for (MovingBlock block : movingBlocks) {
					if (block.position.y + block.bounds.height <= bounds.y && bounds.x < block.position.x + block.bounds.width && bounds.x + bounds.width > block.position.x && bounds.y - block.position.y - block.bounds.height < distance)
						distance = bounds.y - block.position.y - block.bounds.height;
					if (distance == 0)
						block.setPlayer(player);
				}
			}
			else {
				int y = (int) Math.floor(bounds.y);
				boolean found = false;
				while (!found) {
					for (int i = startX; i < endX; i++) {
						if (dirt[(y + (int)bounds.height) * width + i]) {
							found = true;
							break;
						}
					}
					y++;
				}
				distance = y - bounds.y - 1;
				for (MovingBlock block : movingBlocks) {
					if (block.position.y >= bounds.y + bounds.height && bounds.x < block.position.x + block.bounds.width && bounds.x + bounds.width > block.position.x && block.position.y - bounds.y - bounds.height < distance)
						distance = block.position.y - bounds.y - bounds.height;
					if (distance == 0)
						block.setPlayer(player);
				}
			}
		} catch (ArrayIndexOutOfBoundsException e ) {
			return Integer.MAX_VALUE;
		}
		return distance;
	}
	
	public Array<Block> getBlocks() {
		return blocks;
	}
	
	public boolean isMortSubite(Rectangle bounds) {
		int startX = (int) Math.floor(bounds.x);
		int endX = (int) Math.ceil(bounds.x + bounds.width);
		int startY = (int) Math.floor(bounds.y);
		int endY = (int) Math.ceil(bounds.y + bounds.height);
		for (int i = startX; i < endX; i++)
			for (int j = startY; j < endY; j++)
				if (kill[i][j])
					return true;
		return false;
	}
	
	
	public void addBlock(int x, int y, int w, int h) {
		if (x + w >= WorldRenderer.CAMERA_WIDTH || y + h >= WorldRenderer.CAMERA_HEIGHT)
			return;
		this.blocks.add(new Block(x, y, w, h));
		for (int i = 0; i < w; i++)
			for (int j = 0; j < h; j++)
				dirt[x + i + this.width * (y + j)] = true;
	}
	
	private void resetBlocks() {
		for (int i = 0; i < dirt.length; i++)
			dirt[i] = false;
		for (int i = 0; i < kill.length; i++)
			for (int j = 0; j < kill[0].length; j++)
			kill[i][j] = false;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public char [][] getLevelData() {
		return level.getLevelData();
	}
	
	public Array<MovingBlock> getMovingBlocks() {
		return this.movingBlocks;
	}
	
	public float getStateTime() {
		return stateTime;
	}

	public Array<Star> getStars() {
		return stars;
	}
	
	public int getStarsCollected() {
		return starsCollected;
	}
	
	public int getTotalStars() {
		return starsTotal;
	}
	
	public Vector2 getFlagPosition() {
		return flag;
	}

	public boolean isFinished() {
		return finished;
	}

	public void setFinished(boolean finished) {
		this.finished = finished;
	}
	
	

}
