package com.octoforce.games.ld29.model;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class Block {
	
	Vector2 position;
	Rectangle bounds;
	
	public Block(int x, int y, int width, int height) {
		this.position = new Vector2(x, y);
		this.bounds = new Rectangle(x, y, width, height);
	}

	public Vector2 getPosition() {
		return position;
	}

	public void setPosition(Vector2 position) {
		this.position = position;
		this.bounds.x = position.x;
		this.bounds.y = position.y;
	}

	public Rectangle getBounds() {
		return bounds;
	}
	
	public boolean containsIncludingBorder(float x, float y) {
		return position.x <= x && position.x + bounds.width >= x && position.y <= y && position.y + bounds.height >= y;
	}

}
