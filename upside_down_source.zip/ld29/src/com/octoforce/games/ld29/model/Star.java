package com.octoforce.games.ld29.model;

public class Star extends Block {

	public Star(int x, int y) {
		super(x, y, 1, 1);
	}

}
