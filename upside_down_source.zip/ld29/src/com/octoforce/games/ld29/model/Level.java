package com.octoforce.games.ld29.model;

import java.io.BufferedInputStream;
import java.io.IOException;

import com.badlogic.gdx.files.FileHandle;
import com.octoforce.games.ld29.WorldRenderer;
import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;

public class Level {
	
	char [][] data;
	int width;
	int height;
	
	public Level(FileHandle file) {
		this.width = (int) WorldRenderer.CAMERA_WIDTH;
		this.height = (int) WorldRenderer.CAMERA_HEIGHT;
		
		this.data = new char [height][width];
		
		String levelData = file.readString();
		
		String rows [] = levelData.split("\n");
		String temp [];
		for (int i = 0; i < rows.length; i++) {
			temp = rows[i].split(",");
			for (int j = 0; j < temp.length; j++) {
				data[i][j] = temp[j].isEmpty() ? 'n' : temp[j].charAt(0);
			}
		}
		
		System.out.println("yes");
		
	}
	
	public char [][] getLevelData() {
		return data;
	}

}
