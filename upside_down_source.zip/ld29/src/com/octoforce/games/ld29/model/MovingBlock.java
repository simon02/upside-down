package com.octoforce.games.ld29.model;

import com.badlogic.gdx.math.Vector2;

public class MovingBlock extends Block {

	Vector2 startingPosition;
	Vector2 endPosition;
	Vector2 direction;
	float speed;
	boolean movingAway;
	Player player;
	
	public MovingBlock(int x, int y, int width, int height, Vector2 start, Vector2 end, float speed) {
		super(x, y, width, height);
		this.startingPosition = start;
		this.endPosition = end;
		this.speed = speed;
		player = null;
		movingAway = true;
		direction = endPosition.cpy().add(startingPosition.tmp().mul(-1));
		direction.mul(1 / direction.len());
	}
	
	public void update(float delta) {
		float totalMovingDistance = speed * delta;
		Vector2 movement;
		if (movingAway) {
			float distance = endPosition.dst(position);
			if (totalMovingDistance >= distance)
				movingAway = false;
			movement = direction.cpy().mul(totalMovingDistance);
		}
		else {
			float distance = startingPosition.dst(position);
			if (totalMovingDistance >= distance)
				movingAway = true;
			movement = direction.tmp().mul(-totalMovingDistance);
		}
		setPosition(position.add(movement));
		if (player != null) {
			if (player.getBounds().overlaps(bounds))
				player.increasePosition(movement.x, movement.y);
			else
				player = null;
		}
	}
	
	public void setPlayer(Player p) {
		player = p;
	}

}
